import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;
import java.util.Timer;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class programTask15 {
	
	public static Scanner scanner = new Scanner(System.in);
	
	public static volatile AtomicBoolean exit = new AtomicBoolean(true);

	public static void main(String[] args) {
		
		//Scanner scanner = new Scanner(System.in);
		
		Thread thread = null;
		
		try {
			
			//JSONObject info = new JSONObject(requestURL("https://financialmodelingprep.com/api/v3/forex/USDSEK"));
			
			thread = new Thread() {
				public String pad8(String s) {
					while(s.length()<8) {
						s=s+" ";
					}
					return s;
				}
				public String pad20(String s) {
					while(s.length()<20) {
						s=s+" ";
					}
					return s;
				}
				public void run() {
					
					
					Double[] oldValues = {0.0,0.0,0.0,0.0,0.0,0.0};
					String[] names = {"High","Low","Ask","Changes","Bid","Open"};
					
					
					
					while(exit.get()) {
						
						try {
							System.out.print("\033[H\033[2J");  
						    System.out.flush();
						    
							
							System.out.println("Wednesday group task 2019-09-18\nElliot Gustafsson, Andreas Poulsen, Victor Heijler.");
							
							JSONObject info = new JSONObject(requestURL("https://financialmodelingprep.com/api/v3/forex/USDSEK"));
							
							String ticker = info.get("ticker").toString();
							
							Double[] newValues = {info.getDouble("high"),info.getDouble("low"),info.getDouble("ask"),info.getDouble("changes"),info.getDouble("bid"),info.getDouble("open")};
							
							
							
							String dateString = info.getString("date");
							Date date = null;
														
							date = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss").parse(dateString);
							
							System.out.println(date);
							System.out.println(ticker+" |Old                 |New                 | ");
							
							
							for(int i=0;i<oldValues.length;i++) {
								String output=pad8(names[i])+"|";
								
								output=output+pad20(oldValues[i].toString())+"|";
								
								if(oldValues[i]<newValues[i]) {
									output=output+"\u001B[32m"+pad20(newValues[i].toString())+"\u001B[0m";
								}
								else if(oldValues[i]>newValues[i]) {								
									output=output+"\u001B[31m"+pad20(newValues[i].toString())+"\u001B[0m";
								}
								else {
									output=output+"\u001B[0m"+pad20(newValues[i].toString());
								}
								System.out.println(output+"|");
							}
							for(int i=0;i<oldValues.length;i++) {
								oldValues[i]=newValues[i];
							}
							
							
							
							System.out.print("Type \"exit\" to quit: ");
													
							TimeUnit.SECONDS.sleep(9);
						}  catch (ParseException e) {
							e.printStackTrace();
						} catch (InterruptedException e) {
							System.out.println("Program stopped");
						} catch (JSONException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						} catch (Exception e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
				};
			};
			
			thread.start();
			
			
		
			
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		while(true) {
			scanner=new Scanner(System.in);
			String s = scanner.nextLine();

			if(s.contains("exit")) {
				exit.set(false);
				thread.interrupt();
				
				break;
			}
		}
		
		

	}
	public static String requestURL(String url) throws Exception{
        // Set URL
        URLConnection connection = new URL(url).openConnection();
        // Set property - avoid 403 (CORS)
        connection.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.95 Safari/537.11");
        // Create connection
        connection.connect();
        // Create a buffer of the input
        BufferedReader buffer  = new BufferedReader(new InputStreamReader(connection.getInputStream()));
        // Convert the response into a single string
        StringBuilder stringBuilder = new StringBuilder();
        String line;
        while ((line = buffer.readLine()) != null) {
            stringBuilder.append(line);
        }
        // return the response
        return stringBuilder.toString();
    }

}
